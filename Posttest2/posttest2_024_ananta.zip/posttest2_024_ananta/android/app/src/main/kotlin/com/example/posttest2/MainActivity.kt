package com.example.posttest2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
