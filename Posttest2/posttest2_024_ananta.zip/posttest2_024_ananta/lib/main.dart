import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // Ini adalah class MyApp,  root dari aplikasi.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Todo App',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF7D7C7C)),
        useMaterial3: true,
      ),
      home: const MyHomePage(),
    );
  }
}

class MyHomePage extends StatelessWidget {
  const MyHomePage({super.key});

  @override
  // Ini adalah bagian bar pada bagian atas aplikasi
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF2E4F4F),
        title: const Text(
          // Ini adalah bagian text pada bar aplikasi
          "Todo App",
          style: TextStyle(
            color: Colors.white,
            fontSize: 25,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),

      body: SingleChildScrollView(
        child: Padding(
          // memberikan padding pada semua container 
          padding: const EdgeInsets.all(12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Ini adalah bagian judul "Informasi Tugas".
              const Padding(
                padding:
                    EdgeInsets.only(bottom: 12), // Tambahkan jarak di bawah
                child: Text(
                  "Informasi Tugas",
                  style: TextStyle(fontWeight: FontWeight.w200, fontSize: 20),
                ),
              ),

              Center(
                child: Row(
                  mainAxisAlignment:
                      MainAxisAlignment.spaceBetween,
                  children: [
                    // Container pertama (Total Tugas)
                    Container(
                      width: 115,
                      height: 75,
                      margin: const EdgeInsets.only(right: 7),
                      decoration: const BoxDecoration(
                        color: Color(0xFF0E8388),
                        borderRadius: BorderRadius.all(Radius.circular(10)),
                      ),
                      child: const Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Padding(
                            padding: EdgeInsets.only(left: 10, top: 5),
                            child: Text(
                              'Total Tugas', // teks pertama
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 14,
                              ),
                            ),
                          ),
                          Padding(
                            padding: EdgeInsets.only(left: 10),
                            child: Row(
                              children: [
                                Text(
                                  '12', // teks kedua
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 32,
                                  ),
                                ),
                                SizedBox(width: 5),
                                Text(
                                  'Tugas', // teks ketiga
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 14,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),

                    // Container kedua (Tugas Selesai)
                    Container(
                      width: 115,
                      height: 75,
                      margin: const EdgeInsets.only(right: 7),
                      decoration: const BoxDecoration(
                        color: Color.fromARGB(255, 99, 123, 117),
                        borderRadius: BorderRadius.all(Radius.circular(10)),
                      ),
                      child: const Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Padding(
                            padding: EdgeInsets.only(left: 10, top: 5),
                            child: Text(
                              'Tugas Selesai', //teks pertama
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 14,
                              ),
                            ),
                          ),
                          Padding(
                            padding: EdgeInsets.only(left: 10),
                            child: Row(
                              children: [
                                Text(
                                  '3', // teks kedua
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 32,
                                  ),
                                ),
                                SizedBox(width: 5),
                                Text(
                                  'Tugas', //teks ketiga
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 14,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),

                    // Container ketiga (Tugas Hari Ini)
                    Container(
                      width: 115,
                      height: 75,
                      margin: const EdgeInsets.only(right: 7),
                      decoration: const BoxDecoration(
                        color: Color.fromARGB(255, 78, 112, 108),
                        borderRadius: BorderRadius.all(Radius.circular(10)),
                      ),
                      child: const Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Padding(
                            padding: EdgeInsets.only(left: 10, top: 5),
                            child: Text(
                              'Tugas Hari Ini', //teks pertama
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 14,
                              ),
                            ),
                          ),
                          Padding(
                            padding: EdgeInsets.only(left: 10),
                            child: Row(
                              children: [
                                Text(
                                  '2', // teks kedua
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 32,
                                  ),
                                ),
                                SizedBox(width: 5),
                                Text(
                                  'Tugas', // teks ketiga
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 14,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),

              // ListTile pertama
              Padding(
                padding: const EdgeInsets.only(
                    top: 10), // Tambahkan jarak di atasnya
                child: ListTile(
                  leading: Container(
                    height: 40,
                    width: 40,
                    margin: const EdgeInsets.only(right: 7),
                    decoration: const BoxDecoration(
                      color: Color.fromARGB(255, 225, 95, 39),
                      shape: BoxShape.circle,
                    ),
                  ),
                  subtitle: const Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "2109106024",
                        style: TextStyle(
                            fontWeight: FontWeight.bold, fontSize: 20),
                      ),
                      Text(
                        "26/09/2023",
                        style: TextStyle(
                          color: Colors.grey,
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              // ListTile kedua
              ListTile(
                leading: Container(
                  height: 40,
                  width: 40,
                  margin: const EdgeInsets.only(right: 7),
                  decoration: const BoxDecoration(
                    color: Color.fromARGB(255, 29, 161, 101),
                    shape: BoxShape.circle,
                  ),
                ),
                subtitle: const Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Ananta Yusra P.A",
                      style:
                          TextStyle(fontWeight: FontWeight.bold, fontSize: 20),
                    ),
                    Text(
                      "26/09/2023",
                      style: TextStyle(
                          color: Colors
                              .grey
                          ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),

      // FloatingActionButton dengan label "Tambah"
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {},
        tooltip: 'Tambah',
        label: const Text("Tambah", style: TextStyle(color: Colors.white)),
        icon: const Icon(Icons.add, color: Colors.white),
        backgroundColor: Color(0xFF2E4F4F), // Warna latar belakang tombol
      ),
    );
  }
}
